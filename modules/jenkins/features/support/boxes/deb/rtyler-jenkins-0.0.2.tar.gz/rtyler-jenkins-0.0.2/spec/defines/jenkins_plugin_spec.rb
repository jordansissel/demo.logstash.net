
require 'spec_helper'

describe 'jenkins::plugin' do

end
